create database TrainBookingSystem;

-- Create the Users table
CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY,
    Username VARCHAR(50) NOT NULL,
    Password VARCHAR(50) NOT NULL,
    UserType VARCHAR(20) NOT NULL
);

-- Create the Trains table
CREATE TABLE Trains (
    TrainID INT PRIMARY KEY IDENTITY,
    TrainNumber VARCHAR(10) NOT NULL,
    TrainName VARCHAR(100) NOT NULL
);
-- Create the TrainSchedule table
CREATE TABLE TrainSchedule (
    ScheduleID INT PRIMARY KEY IDENTITY,
    TrainID INT NOT NULL,
    Departure VARCHAR(50) NOT NULL,
    Destination VARCHAR(50) NOT NULL,
	DepartureTime VARCHAR(50) NOT NULL,
	ArrivalTime VARCHAR(50) NOT NULL
    
    CONSTRAINT FK_TrainSchedule_Trains FOREIGN KEY (TrainID) REFERENCES Trains (TrainID)
);

-- Create the Seats table
CREATE TABLE Seats (
    SeatID INT PRIMARY KEY IDENTITY,
    ScheduleID INT NOT NULL,
    DepartureDate DATE NOT NULL,
    AvailableSeats INT NOT NULL default 100,
    CONSTRAINT FK_Seats_TrainSchedule FOREIGN KEY (ScheduleID) REFERENCES TrainSchedule (ScheduleID)
);
-- Create the Bookings table
CREATE TABLE Bookings (
    BookingID INT PRIMARY KEY IDENTITY,
    ScheduleID INT NOT NULL,
    DepartureDate DATE NOT NULL,
    RequiredSeats INT NOT NULL,
    UserID INT NOT NULL,
    CONSTRAINT FK_Bookings_TrainSchedule FOREIGN KEY (ScheduleID) REFERENCES TrainSchedule (ScheduleID),
    CONSTRAINT FK_Bookings_Users FOREIGN KEY (UserID) REFERENCES Users (UserID)
);

-- Create the TrainStations table
CREATE TABLE TrainStations (
    StationID INT PRIMARY KEY IDENTITY,
    StationName VARCHAR(50) NOT NULL
);