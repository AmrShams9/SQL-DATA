﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase
{
    public partial class Update : Form
    {
        public Update()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string oldUsername = OldUsername.Text.Trim();
            string newUsername = NewUsername.Text.Trim();
            string oldPassword = OldPassword.Text.Trim();
            string newPassword = NewPassword.Text.Trim();

            if (string.IsNullOrEmpty(oldUsername) || string.IsNullOrEmpty(newUsername) ||
                string.IsNullOrEmpty(oldPassword) || string.IsNullOrEmpty(newPassword))
            {
                MessageBox.Show("Please fill in all the fields.");
                return;
            }

            // Perform update logic here
            // Assuming you have a database connection, you can execute an update query
            // to update the username and password for the specified user
            string updateQuery = "UPDATE Users SET Username = @NewUsername, Password = @NewPassword " +
                                 "WHERE Username = @OldUsername AND Password = @OldPassword";

            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True"))
            {
                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@NewUsername", newUsername);
                    command.Parameters.AddWithValue("@NewPassword", newPassword);
                    command.Parameters.AddWithValue("@OldUsername", oldUsername);
                    command.Parameters.AddWithValue("@OldPassword", oldPassword);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Update successful.");
                    }
                    else
                    {
                        MessageBox.Show("Update failed. Please check the provided credentials.");
                    }
                }
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
