﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase
{
    public partial class Trip : Form
    {
        public Trip()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Retrieve the TrainID entered by the user
            int trainID;
            if (!int.TryParse(textBox1.Text, out trainID))
            {
                MessageBox.Show("Please enter a valid Train ID.", "Invalid Train ID", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Retrieve the departure, destination, departure time, and arrival time entered by the user
            string departure = textBox2.Text;
            string destination = textBox3.Text;
            string departureTime = textBox4.Text;
            string arrivalTime = textBox5.Text;

            // Perform validation for the input values
            if (string.IsNullOrWhiteSpace(departure) || string.IsNullOrWhiteSpace(destination) ||
                string.IsNullOrWhiteSpace(departureTime) || string.IsNullOrWhiteSpace(arrivalTime))
            {
                MessageBox.Show("Please enter all the fields.", "Incomplete Fields", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check if the train record with the specified ID exists in the database
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True"))
            {
                connection.Open();

                string selectQuery = "SELECT COUNT(*) FROM Trains WHERE TrainID = @TrainID";
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@TrainID", trainID);

                    // Execute the command and check the result
                    int rowCount = (int)command.ExecuteScalar();
                    if (rowCount == 0)
                    {
                        MessageBox.Show("Train ID not found in the database.", "Train Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                //!!! IMPORTANT PART !!!

                // Add a new entry in the TrainSchedule table
                string insertQuery = "INSERT INTO TrainSchedule (TrainID, Departure, Destination, DepartureTime, ArrivalTime) " +
                                     "VALUES (@TrainID, @Departure, @Destination, @DepartureTime, @ArrivalTime)";
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@TrainID", trainID);
                    command.Parameters.AddWithValue("@Departure", departure);
                    command.Parameters.AddWithValue("@Destination", destination);
                    command.Parameters.AddWithValue("@DepartureTime", departureTime);
                    command.Parameters.AddWithValue("@ArrivalTime", arrivalTime);

                    // Execute the command
                    command.ExecuteNonQuery();
                }
            }

            // Display a success message
            MessageBox.Show("Train schedule added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Retrieve the TrainID entered by the user
            int trainID;
            if (!int.TryParse(textBox1.Text, out trainID))
            {
                MessageBox.Show("Please enter a valid Train ID.", "Invalid Train ID", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Confirm the deletion with the user
            DialogResult result = MessageBox.Show("Are you sure you want to delete the train data?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No)
            {
                return;
            }

            // Delete the train's data from the database
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True"))
            {
                connection.Open();

                // Check if the train record with the specified ID exists in the database
                string selectQuery = "SELECT COUNT(*) FROM Trains WHERE TrainID = @TrainID";
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@TrainID", trainID);

                    // Execute the command and check the result
                    int rowCount = (int)command.ExecuteScalar();
                    if (rowCount == 0)
                    {
                        MessageBox.Show("Train ID not found in the database.", "Train Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                // Delete the train's data from the database
                string deleteQuery = "DELETE FROM TrainSchedule WHERE TrainID = @TrainID";
                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@TrainID", trainID);

                    // Execute the command
                    command.ExecuteNonQuery();
                }
            }

            // Display a success message
            MessageBox.Show("Train data deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Retrieve the TrainID entered by the user
            int trainID;
            if (!int.TryParse(textBox1.Text, out trainID))
            {
                MessageBox.Show("Please enter a valid Train ID.", "Invalid Train ID", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Retrieve the updated values entered by the user
            string departure = textBox2.Text;
            string destination = textBox3.Text;
            string departureTime = textBox4.Text;
            string arrivalTime = textBox5.Text;

            // Perform validation for the input values
            if (string.IsNullOrWhiteSpace(departure) || string.IsNullOrWhiteSpace(destination) ||
                string.IsNullOrWhiteSpace(departureTime) || string.IsNullOrWhiteSpace(arrivalTime))
            {
                MessageBox.Show("Please enter all the fields.", "Incomplete Fields", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            //!!! IMPORTANT PART !!!

            // Update the train's data in the database
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True"))
            {
                connection.Open();

                // Check if the train record with the specified ID exists in the database
                string selectQuery = "SELECT COUNT(*) FROM Trains WHERE TrainID = @TrainID";
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@TrainID", trainID);

                    // Execute the command and check the result
                    int rowCount = (int)command.ExecuteScalar();
                    if (rowCount == 0)
                    {
                        MessageBox.Show("Train ID not found in the database.", "Train Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                // Update the train's data in the TrainSchedule table
                string updateTrainScheduleQuery = "UPDATE TrainSchedule SET Departure = @Departure, Destination = @Destination, DepartureTime = @DepartureTime, ArrivalTime = @ArrivalTime WHERE TrainID = @TrainID";
                using (SqlCommand command = new SqlCommand(updateTrainScheduleQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@Departure", departure);
                    command.Parameters.AddWithValue("@Destination", destination);
                    command.Parameters.AddWithValue("@DepartureTime", departureTime);
                    command.Parameters.AddWithValue("@ArrivalTime", arrivalTime);
                    command.Parameters.AddWithValue("@TrainID", trainID);

                    // Execute the command
                    command.ExecuteNonQuery();
                }
            }

            // Display a success message
            MessageBox.Show("Train data updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }

        private void Trip_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'trainBookingSystemDataSet2.TrainSchedule' table. You can move, or remove it, as needed.
            this.trainScheduleTableAdapter1.Fill(this.trainBookingSystemDataSet2.TrainSchedule);
            // TODO: This line of code loads data into the 'trainBookingSystemDataSet2.Seats' table. You can move, or remove it, as needed.
            this.seatsTableAdapter.Fill(this.trainBookingSystemDataSet2.Seats);
            // TODO: This line of code loads data into the 'trainBookingSystemDataSet1.TrainSchedule' table. You can move, or remove it, as needed.
            this.trainScheduleTableAdapter.Fill(this.trainBookingSystemDataSet1.TrainSchedule);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True"))
            {
                connection.Open();

                // Query to retrieve the schedule data
                string selectQuery = "SELECT ts.ScheduleID, ts.TrainID, ts.Departure, ts.DepartureTime, ts.ArrivalTime, s.AvailableSeats, ts.Destination " +
                                     "FROM TrainSchedule ts " +
                                     "INNER JOIN Seats s ON ts.ScheduleID = s.ScheduleID";

                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    // Create a SqlDataAdapter to fill the DataTable
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

                    // Fill the DataTable with the data from the query
                    dataAdapter.Fill(dataTable);
                }
            }

            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dataTable;

        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
