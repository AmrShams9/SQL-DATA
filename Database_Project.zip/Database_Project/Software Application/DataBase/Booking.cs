﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase
{
    public partial class Booking : Form
    {
        public Booking()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
           
            this.seatsTableAdapter.Fill(this.trainBookingSystemDataSet2.Seats);
           
            this.bookingsTableAdapter.Fill(this.trainBookingSystemDataSet2.Bookings);
            
            this.trainScheduleTableAdapter.Fill(this.trainBookingSystemDataSet2.TrainSchedule);
            
            this.trainsTableAdapter.Fill(this.trainBookingSystemDataSet.Trains);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Retrieve the trip ID entered by the user
            int tripID;
            if (!int.TryParse(textBox1.Text, out tripID))
            {
                MessageBox.Show("Please enter a valid Trip ID.", "Invalid Trip ID", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Retrieve the required seats entered by the user
            int requiredSeats;
            if (!int.TryParse(textBox2.Text, out requiredSeats))
            {
                MessageBox.Show("Please enter a valid number of required seats.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Perform the seat booking process
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True"))
            {
                connection.Open();

                // Check if there are enough available seats for the trip
                string selectQuery = "SELECT AvailableSeats FROM Seats WHERE ScheduleID = @ScheduleID";
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    command.Parameters.AddWithValue("@ScheduleID", tripID);

                    // Execute the query and retrieve the available seats
                    object result = command.ExecuteScalar();
                    int availableSeats = result != null && result != DBNull.Value ? Convert.ToInt32(result) : 0;

                    // Check if there are enough available seats
                    if (availableSeats >= requiredSeats)
                    {
                        // Update the available seats count
                        string updateQuery = "UPDATE Seats SET AvailableSeats = AvailableSeats - @RequiredSeats WHERE ScheduleID = @ScheduleID";
                        using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                        {
                            updateCommand.Parameters.AddWithValue("@RequiredSeats", requiredSeats);
                            updateCommand.Parameters.AddWithValue("@ScheduleID", tripID);

                            // Execute the update query to book the seats
                            updateCommand.ExecuteNonQuery();
                        }

                        // Display a success message
                        MessageBox.Show("Seats booked successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Not enough available seats for the trip.", "Seats Unavailable", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Retrieve the trip ID entered by the user
            int tripID;
            if (!int.TryParse(textBox1.Text, out tripID))
            {
                MessageBox.Show("Please enter a valid Trip ID.", "Invalid Trip ID", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Retrieve the required seats entered by the user
            int requiredSeats;
            if (!int.TryParse(textBox2.Text, out requiredSeats))
            {
                MessageBox.Show("Please enter a valid number of required seats.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Perform the cancel booking process
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True"))
            {
                connection.Open();

                // Update the available seats count
                string updateQuery = "UPDATE Seats SET AvailableSeats = AvailableSeats + @RequiredSeats WHERE ScheduleID = @ScheduleID";
                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@RequiredSeats", requiredSeats);
                    updateCommand.Parameters.AddWithValue("@ScheduleID", tripID);

                    // Execute the update query to cancel the seats
                    int rowsAffected = updateCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // Display a success message
                        MessageBox.Show("Seats canceled successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("No seats were canceled for the trip.", "Seats Unavailable", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }


            }

            private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True"))
            {
                connection.Open();

                // Query to retrieve the schedule data
                string selectQuery = "SELECT ts.ScheduleID, ts.TrainID, ts.Departure, ts.DepartureTime, ts.ArrivalTime, s.AvailableSeats, ts.Destination " +
                                     "FROM TrainSchedule ts " +
                                     "INNER JOIN Seats s ON ts.ScheduleID = s.ScheduleID";

                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    // Create a SqlDataAdapter to fill the DataTable
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

                    // Fill the DataTable with the data from the query
                    dataAdapter.Fill(dataTable);
                }
            }

            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dataTable;

        }
    }
}
