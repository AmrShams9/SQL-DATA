﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataBase
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();
            string userType = Choose.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(userType))
            {
                MessageBox.Show("Please fill in all the fields.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True"))
                {
                    connection.Open();

                    string checkQuery = $"SELECT COUNT(*) FROM Users WHERE Username = '{username}'";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        int count = (int)checkCommand.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("Username already exists. Please choose a different Username.");
                            return;
                        }
                    }

                    string insertQuery = $"INSERT INTO Users (Username, Password, UserType) VALUES ('{username}', '{password}', '{userType}')";
                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("User signed up successfully.");
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error occurred: {ex.Message}");
            }
        }

        private void ClearFields()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            Choose.SelectedIndex = -1;
        }

        private void Choose_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedUserType = Choose.SelectedItem as string;

            if (selectedUserType == "Admin")
            {
                MessageBox.Show("Admin selected");
            }
            else if (selectedUserType == "Customer")
            {
                MessageBox.Show("Customer selected");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();
            string userType = Choose.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(userType))
            {
                MessageBox.Show("Please fill in all the fields.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True"))
                {
                    connection.Open();

                    string query = $"SELECT COUNT(*) FROM Users WHERE Username = '{username}' AND Password = '{password}' AND UserType = '{userType}'";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        int count = (int)command.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("User signed in successfully.");
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("Invalid Username, Password, or User Type. Please try again.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error occurred: {ex.Message}");
            }


        }
    }
}
