﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase
{
    public partial class Train : Form
    {
        public Train()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Retrieve the TrainNumber and TrainName entered by the user
            string trainNumber = textBox1.Text;
            string trainName = textBox2.Text;

            // Perform validation for the input values
            if (string.IsNullOrWhiteSpace(trainNumber) || string.IsNullOrWhiteSpace(trainName))
            {
                MessageBox.Show("Please enter TrainNumber and TrainName.", "Incomplete Fields", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

 

            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True")) 
            {
                connection.Open();

                // Create a SQL command to insert the new train into the database
                string insertQuery = "INSERT INTO Trains (TrainNumber, TrainName) VALUES (@TrainNumber, @TrainName)";
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@TrainNumber", trainNumber);
                    command.Parameters.AddWithValue("@TrainName", trainName);

                    // Execute the command
                    command.ExecuteNonQuery();
                }

            }
        }

            private void Train_Load(object sender, EventArgs e)
        {
        
            this.trainsTableAdapter.Fill(this.trainBookingSystemDataSet.Trains);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Retrieve the TrainID entered by the user
            int trainID;
            if (!int.TryParse(textBox3.Text, out trainID))
            {
                MessageBox.Show("Please enter a valid Train ID.", "Invalid Train ID", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Retrieve the TrainNumber and TrainName entered by the user
            string trainNumber = textBox1.Text;
            string trainName = textBox2.Text;

            // Perform validation for the input values
            if (string.IsNullOrWhiteSpace(trainNumber) || string.IsNullOrWhiteSpace(trainName))
            {
                MessageBox.Show("Please enter Train Number and Train Name.", "Incomplete Fields", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Update the train record in the database
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True"))
            {
                connection.Open();

                // Check if the train record with the specified ID exists in the database
                string selectQuery = "SELECT COUNT(*) FROM Trains WHERE TrainID = @TrainID";
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@TrainID", trainID);

                    // Execute the command and check the result
                    int rowCount = (int)command.ExecuteScalar();
                    if (rowCount == 0)
                    {
                        MessageBox.Show("Train ID not found in the database.", "Train Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                // Update the train record in the database
                string updateQuery = "UPDATE Trains SET TrainNumber = @TrainNumber, TrainName = @TrainName WHERE TrainID = @TrainID";
                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@TrainNumber", trainNumber);
                    command.Parameters.AddWithValue("@TrainName", trainName);
                    command.Parameters.AddWithValue("@TrainID", trainID);

                    // Execute the command
                    command.ExecuteNonQuery();
                }
            }

            // Display a success message
            MessageBox.Show("Train updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Retrieve the TrainID entered by the user
            int trainID;
            if (!int.TryParse(textBox3.Text, out trainID))
            {
                MessageBox.Show("Please enter a valid Train ID.", "Invalid Train ID", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            

            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True")) 
            {
                connection.Open();

                // Check if the train record with the specified ID exists in the database
                string selectQuery = "SELECT COUNT(*) FROM Trains WHERE TrainID = @TrainID";
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@TrainID", trainID);

                    // Execute the command and check the result
                    int rowCount = (int)command.ExecuteScalar();
                    if (rowCount == 0)
                    {
                        MessageBox.Show("Train ID not found in the database.", "Train Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                // Delete the train record from the database
                string deleteQuery = "DELETE FROM Trains WHERE TrainID = @TrainID";
                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@TrainID", trainID);

                    // Execute the command
                    command.ExecuteNonQuery();
                }
            }

            // display a success message or perform any additional actions
            MessageBox.Show("Train deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6NBDDIQ;Initial Catalog=TrainBookingSystem;Integrated Security=True")) 
            {
                connection.Open();

                // Retrieve the train data from the database
                string selectQuery = "SELECT TrainID, TrainNumber, TrainName FROM Trains";
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    // Create a DataTable to hold the retrieved data
                    DataTable trainDataTable = new DataTable();

                    // Create a SqlDataAdapter to fill the DataTable with the query results
                    SqlDataAdapter adapter = new SqlDataAdapter(command);

                    // Fill the DataTable with the data from the database
                    adapter.Fill(trainDataTable);

                    // Set the DataGridView's DataSource to the DataTable
                    dataGridView1.DataSource = trainDataTable;
                }
            }
        }
    }
}
