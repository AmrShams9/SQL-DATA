﻿namespace DataBase
{
    partial class Booking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.trainBookingSystemDataSet = new DataBase.TrainBookingSystemDataSet();
            this.trainsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trainsTableAdapter = new DataBase.TrainBookingSystemDataSetTableAdapters.TrainsTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.trainScheduleBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.trainBookingSystemDataSet2 = new DataBase.TrainBookingSystemDataSet2();
            this.trainScheduleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trainScheduleTableAdapter = new DataBase.TrainBookingSystemDataSet2TableAdapters.TrainScheduleTableAdapter();
            this.fKBookingsTrainScheduleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookingsTableAdapter = new DataBase.TrainBookingSystemDataSet2TableAdapters.BookingsTableAdapter();
            this.seatsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.seatsTableAdapter = new DataBase.TrainBookingSystemDataSet2TableAdapters.SeatsTableAdapter();
            this.fKBookingsTrainScheduleBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.ScheduleID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableSeats = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departureDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.destinationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departureTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.arrivalTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.trainBookingSystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainScheduleBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainBookingSystemDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainScheduleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBookingsTrainScheduleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seatsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBookingsTrainScheduleBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 211);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "BOOK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(148, 211);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "CANCEL";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Schedule ID";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(148, 130);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // trainBookingSystemDataSet
            // 
            this.trainBookingSystemDataSet.DataSetName = "TrainBookingSystemDataSet";
            this.trainBookingSystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // trainsBindingSource
            // 
            this.trainsBindingSource.DataMember = "Trains";
            this.trainsBindingSource.DataSource = this.trainBookingSystemDataSet;
            // 
            // trainsTableAdapter
            // 
            this.trainsTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ScheduleID,
            this.AvailableSeats,
            this.trainIDDataGridViewTextBoxColumn,
            this.departureDataGridViewTextBoxColumn,
            this.destinationDataGridViewTextBoxColumn,
            this.departureTimeDataGridViewTextBoxColumn,
            this.arrivalTimeDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.trainScheduleBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(254, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(936, 430);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // trainScheduleBindingSource1
            // 
            this.trainScheduleBindingSource1.DataMember = "TrainSchedule";
            this.trainScheduleBindingSource1.DataSource = this.trainBookingSystemDataSet2;
            // 
            // trainBookingSystemDataSet2
            // 
            this.trainBookingSystemDataSet2.DataSetName = "TrainBookingSystemDataSet2";
            this.trainBookingSystemDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // trainScheduleBindingSource
            // 
            this.trainScheduleBindingSource.DataMember = "TrainSchedule";
            this.trainScheduleBindingSource.DataSource = this.trainBookingSystemDataSet2;
            // 
            // trainScheduleTableAdapter
            // 
            this.trainScheduleTableAdapter.ClearBeforeFill = true;
            // 
            // fKBookingsTrainScheduleBindingSource
            // 
            this.fKBookingsTrainScheduleBindingSource.DataMember = "FK_Bookings_TrainSchedule";
            this.fKBookingsTrainScheduleBindingSource.DataSource = this.trainScheduleBindingSource;
            // 
            // bookingsTableAdapter
            // 
            this.bookingsTableAdapter.ClearBeforeFill = true;
            // 
            // seatsBindingSource
            // 
            this.seatsBindingSource.DataMember = "Seats";
            this.seatsBindingSource.DataSource = this.trainBookingSystemDataSet2;
            // 
            // seatsTableAdapter
            // 
            this.seatsTableAdapter.ClearBeforeFill = true;
            // 
            // fKBookingsTrainScheduleBindingSource1
            // 
            this.fKBookingsTrainScheduleBindingSource1.DataMember = "FK_Bookings_TrainSchedule";
            this.fKBookingsTrainScheduleBindingSource1.DataSource = this.trainScheduleBindingSource;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Required Seats";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(148, 160);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 6;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(651, 478);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 31);
            this.button3.TabIndex = 7;
            this.button3.Text = "SHOW DATA";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // ScheduleID
            // 
            this.ScheduleID.DataPropertyName = "ScheduleID";
            this.ScheduleID.HeaderText = "ScheduleID";
            this.ScheduleID.MinimumWidth = 6;
            this.ScheduleID.Name = "ScheduleID";
            this.ScheduleID.ReadOnly = true;
            this.ScheduleID.Width = 125;
            // 
            // AvailableSeats
            // 
            this.AvailableSeats.DataPropertyName = "AvailableSeats";
            this.AvailableSeats.HeaderText = "AvailableSeats";
            this.AvailableSeats.MinimumWidth = 6;
            this.AvailableSeats.Name = "AvailableSeats";
            this.AvailableSeats.ReadOnly = true;
            this.AvailableSeats.Width = 125;
            // 
            // trainIDDataGridViewTextBoxColumn
            // 
            this.trainIDDataGridViewTextBoxColumn.DataPropertyName = "TrainID";
            this.trainIDDataGridViewTextBoxColumn.HeaderText = "TrainID";
            this.trainIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.trainIDDataGridViewTextBoxColumn.Name = "trainIDDataGridViewTextBoxColumn";
            this.trainIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // departureDataGridViewTextBoxColumn
            // 
            this.departureDataGridViewTextBoxColumn.DataPropertyName = "Departure";
            this.departureDataGridViewTextBoxColumn.HeaderText = "Departure";
            this.departureDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.departureDataGridViewTextBoxColumn.Name = "departureDataGridViewTextBoxColumn";
            this.departureDataGridViewTextBoxColumn.Width = 125;
            // 
            // destinationDataGridViewTextBoxColumn
            // 
            this.destinationDataGridViewTextBoxColumn.DataPropertyName = "Destination";
            this.destinationDataGridViewTextBoxColumn.HeaderText = "Destination";
            this.destinationDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.destinationDataGridViewTextBoxColumn.Name = "destinationDataGridViewTextBoxColumn";
            this.destinationDataGridViewTextBoxColumn.Width = 125;
            // 
            // departureTimeDataGridViewTextBoxColumn
            // 
            this.departureTimeDataGridViewTextBoxColumn.DataPropertyName = "DepartureTime";
            this.departureTimeDataGridViewTextBoxColumn.HeaderText = "DepartureTime";
            this.departureTimeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.departureTimeDataGridViewTextBoxColumn.Name = "departureTimeDataGridViewTextBoxColumn";
            this.departureTimeDataGridViewTextBoxColumn.Width = 125;
            // 
            // arrivalTimeDataGridViewTextBoxColumn
            // 
            this.arrivalTimeDataGridViewTextBoxColumn.DataPropertyName = "ArrivalTime";
            this.arrivalTimeDataGridViewTextBoxColumn.HeaderText = "ArrivalTime";
            this.arrivalTimeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.arrivalTimeDataGridViewTextBoxColumn.Name = "arrivalTimeDataGridViewTextBoxColumn";
            this.arrivalTimeDataGridViewTextBoxColumn.Width = 125;
            // 
            // BOOKING
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 560);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "BOOKING";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trainBookingSystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainScheduleBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainBookingSystemDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainScheduleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBookingsTrainScheduleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seatsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBookingsTrainScheduleBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private TrainBookingSystemDataSet trainBookingSystemDataSet;
        private System.Windows.Forms.BindingSource trainsBindingSource;
        private TrainBookingSystemDataSetTableAdapters.TrainsTableAdapter trainsTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private TrainBookingSystemDataSet2 trainBookingSystemDataSet2;
        private System.Windows.Forms.BindingSource trainScheduleBindingSource;
        private TrainBookingSystemDataSet2TableAdapters.TrainScheduleTableAdapter trainScheduleTableAdapter;
        private System.Windows.Forms.BindingSource fKBookingsTrainScheduleBindingSource;
        private TrainBookingSystemDataSet2TableAdapters.BookingsTableAdapter bookingsTableAdapter;
        private System.Windows.Forms.BindingSource seatsBindingSource;
        private TrainBookingSystemDataSet2TableAdapters.SeatsTableAdapter seatsTableAdapter;
        private System.Windows.Forms.BindingSource trainScheduleBindingSource1;
        private System.Windows.Forms.BindingSource fKBookingsTrainScheduleBindingSource1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScheduleID;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableSeats;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn departureDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn departureTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn arrivalTimeDataGridViewTextBoxColumn;
    }
}